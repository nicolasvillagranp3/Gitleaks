import * as dotenv from "dotenv";
dotenv.config();

// Insecure private keys using for tests only
export const privateKeys = [
    "0xa15c19da241e5b1db20d8dd8ca4b5eeaee01c709b49ec57aa78c2133d3c1b3c9",
    "0xe7af72d241d4dd77bc080ce9234d742f6b22e35b3a660e8c197517b909f63ca8",
    "0x3918f6158deecdeac58823e9c116200edb025db36c89085b0647cec45f3f475f",
    "0x4adb17af9ba53dad177d1e1d93bcac65129cafed84704a0da639be30fe5c9f9c",
    "0xe8829ca5780908bb7e842eb69077410c9e89ed323c8038a634d39c0b301e32f8",
    "0x9b0b6e1f047faf814323b8ce32636f559c4b2fa3b96a8158a3cda5779505dafd"
];