module.exports = {
    skipFiles: ['thirdparty/', 'interfaces/', 'test/']
};
